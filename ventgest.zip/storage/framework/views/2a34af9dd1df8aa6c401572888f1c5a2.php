

<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card shadow-sm border-0">
                <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                    <h4 class="mb-0">Lista de Productos</h4>
                    <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(route('productos.create')); ?>" class="btn btn-light btn-sm">+ Nuevo Producto</a>
                    <?php endif; ?>
                </div>

                <div class="card-body">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                    <?php endif; ?>

                    <div class="table-responsive">
                        <table class="table table-bordered table-hover align-middle">
                            <thead class="table-primary text-center">
                                <tr>
                                    <th>ID</th>
                                    <th>Nombre</th>
                                    <th>Descripción</th>
                                    <th>Precio</th>
                                    <th>Cantidad</th>
                                    <th>Categoría</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($producto->Id_Producto); ?></td>
                                    <td><?php echo e($producto->Nombre); ?></td>
                                    <td><?php echo e($producto->Descripcion); ?></td>
                                    <td>$<?php echo e(number_format($producto->Precio, 2)); ?></td>
                                    <td><?php echo e($producto->Cantidad); ?></td>
                                    <td><?php echo e($producto->categoria->Nombre ?? 'N/A'); ?></td>
                                    <td class="text-center">
                                        <a href="<?php echo e(route('productos.show', $producto->Id_Producto)); ?>" class="btn btn-info btn-sm mb-1">Ver</a>
                                        <?php if(auth()->guard()->check()): ?>
                                        <a href="<?php echo e(route('productos.edit', $producto->Id_Producto)); ?>" class="btn btn-warning btn-sm mb-1">Editar</a>
                                        <form action="<?php echo e(route('productos.destroy', $producto->Id_Producto)); ?>" method="POST" style="display:inline-block;" onsubmit="return confirm('¿Eliminar producto?')">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button class="btn btn-danger btn-sm">Eliminar</button>
                                        </form>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="mt-3">
                        <?php echo e($productos->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\crud\resources\views\productos\index.blade.php ENDPATH**/ ?>