

<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card shadow-sm border-0">
                <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                    <h4 class="mb-0">Lista de Categorías</h4>
                    <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(route('categorias.create')); ?>" class="btn btn-light btn-sm">
                        + Nueva Categoría
                    </a>
                     <?php endif; ?>
                </div>

                <div class="card-body">
                    <?php if($categorias->isEmpty()): ?>
                        <div class="alert alert-info text-center">No hay categorías registradas aún.</div>
                    <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover align-middle">
                            <thead class="table-primary text-center">
                                <tr>
                                    <th>ID</th>
                                    <th>Nombre</th>
                                    <th>Descripción</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($cat->Id_Categoria); ?></td>
                                    <td><?php echo e($cat->Nombre); ?></td>
                                    <td><?php echo e($cat->Descripcion); ?></td>
                                    <td class="text-center">
                                        <a href="<?php echo e(route('categorias.show', $cat->Id_Categoria)); ?>" class="btn btn-info btn-sm mb-1">
                                            Ver
                                        </a>
                                        <?php if(auth()->guard()->check()): ?>
                                        <a href="<?php echo e(route('categorias.edit', $cat->Id_Categoria)); ?>" class="btn btn-warning btn-sm mb-1">
                                            Editar
                                        </a>
                                        <form action="<?php echo e(route('categorias.destroy', $cat->Id_Categoria)); ?>" method="POST" style="display:inline-block;" onsubmit="return confirm('¿Deseas eliminar esta categoría?')">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button class="btn btn-danger btn-sm">Eliminar</button>
                                        </form>
                                         <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\crud\resources\views\categorias\index.blade.php ENDPATH**/ ?>