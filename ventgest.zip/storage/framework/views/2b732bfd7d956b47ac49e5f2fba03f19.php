

<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card shadow-sm border-0">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0">Detalle Producto</h4>
                </div>
                <div class="card-body">
                    <dl class="row">
                        <dt class="col-sm-4">Nombre:</dt>
                        <dd class="col-sm-8"><?php echo e($producto->Nombre); ?></dd>

                        <dt class="col-sm-4">Descripción:</dt>
                        <dd class="col-sm-8"><?php echo e($producto->Descripcion); ?></dd>

                        <dt class="col-sm-4">Precio:</dt>
                        <dd class="col-sm-8">$<?php echo e(number_format($producto->Precio, 2)); ?></dd>

                        <dt class="col-sm-4">Cantidad:</dt>
                        <dd class="col-sm-8"><?php echo e($producto->Cantidad); ?></dd>

                        <dt class="col-sm-4">Categoría:</dt>
                        <dd class="col-sm-8"><?php echo e($producto->categoria->Nombre ?? 'N/A'); ?></dd>
                    </dl>

                    <a href="<?php echo e(route('productos.index')); ?>" class="btn btn-secondary">
                        Volver
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\crud\resources\views\productos\show.blade.php ENDPATH**/ ?>