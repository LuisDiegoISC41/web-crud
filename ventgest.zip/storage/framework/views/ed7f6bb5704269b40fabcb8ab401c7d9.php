

<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card shadow-sm border-0">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0">Detalle del Cliente</h4>
                </div>
                <div class="card-body">
                    <p><strong>Nombre:</strong> <?php echo e($cliente->nombre); ?></p>
                    <p><strong>Apellido:</strong> <?php echo e($cliente->apellido); ?></p>
                    <p><strong>Email:</strong> <?php echo e($cliente->email); ?></p>
                    <p><strong>Teléfono:</strong> <?php echo e($cliente->telefono); ?></p>
                </div>
            </div>
            <a href="<?php echo e(route('clientes.index')); ?>" class="btn btn-secondary mt-3">Volver</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\crud\resources\views\clientes\show.blade.php ENDPATH**/ ?>