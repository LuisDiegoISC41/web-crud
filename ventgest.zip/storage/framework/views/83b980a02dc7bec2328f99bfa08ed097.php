

<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card shadow-sm border-0">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0">Editar Producto</h4>
                </div>

                <div class="card-body">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <h6>Se encontraron los siguientes errores:</h6>
                            <ul class="mb-0">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <form action="<?php echo e(route('productos.update', $producto->Id_Producto)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="mb-3">
                            <label for="Nombre" class="form-label">Nombre</label>
                            <input type="text" name="Nombre" id="Nombre" class="form-control" value="<?php echo e(old('Nombre', $producto->Nombre)); ?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="Descripcion" class="form-label">Descripción</label>
                            <textarea name="Descripcion" id="Descripcion" class="form-control" rows="3"><?php echo e(old('Descripcion', $producto->Descripcion)); ?></textarea>
                        </div>

                        <div class="mb-3">
                            <label for="Precio" class="form-label">Precio</label>
                            <input type="number" name="Precio" id="Precio" class="form-control" step="0.01" value="<?php echo e(old('Precio', $producto->Precio)); ?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="Cantidad" class="form-label">Cantidad</label>
                            <input type="number" name="Cantidad" id="Cantidad" class="form-control" value="<?php echo e(old('Cantidad', $producto->Cantidad)); ?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="fkCategoria" class="form-label">Categoría</label>
                            <select name="fkCategoria" id="fkCategoria" class="form-select" required>
                                <option value="">Seleccione una categoría</option>
                                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($categoria->Id_Categoria); ?>"
                                        <?php echo e(old('fkCategoria', $producto->fkCategoria) == $categoria->Id_Categoria ? 'selected' : ''); ?>>
                                        <?php echo e($categoria->Nombre); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="d-flex justify-content-between">
                            <a href="<?php echo e(route('productos.index')); ?>" class="btn btn-secondary">
                                Cancelar
                            </a>
                            <button type="submit" class="btn btn-primary">
                                Actualizar Producto
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\crud\resources\views\productos\edit.blade.php ENDPATH**/ ?>