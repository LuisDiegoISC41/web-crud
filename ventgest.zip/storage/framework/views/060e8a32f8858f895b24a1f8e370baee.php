

<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card shadow-sm border-0">
                <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                    <h4 class="mb-0">Clientes</h4>
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(route('clientes.create')); ?>" class="btn btn-light btn-sm">
                            + Nuevo Cliente
                        </a>
                    <?php endif; ?>
                </div>

                <div class="card-body">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                    <?php endif; ?>

                    <?php if($clientes->isEmpty()): ?>
                        <div class="alert alert-info text-center">No hay clientes registrados aún.</div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover align-middle text-center">
                                <thead class="table-primary">
                                    <tr>
                                        <th>ID</th>
                                        <th>Nombre</th>
                                        <th>Apellido</th>
                                        <th>Email</th>
                                        <th>Teléfono</th>
                                        <?php if(auth()->guard()->check()): ?> <th>Acciones</th> <?php endif; ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($cliente->id); ?></td>
                                            <td><?php echo e($cliente->nombre); ?></td>
                                            <td><?php echo e($cliente->apellido); ?></td>
                                            <td><?php echo e($cliente->email); ?></td>
                                            <td><?php echo e($cliente->telefono); ?></td>
                                            
                                                <td>
                                                    <a href="<?php echo e(route('clientes.show', $cliente->id)); ?>" class="btn btn-info btn-sm mb-1">Ver</a>
                                                    <?php if(auth()->guard()->check()): ?>
                                                    <a href="<?php echo e(route('clientes.edit', $cliente->id)); ?>" class="btn btn-warning btn-sm mb-1">Editar</a>
                                                    <form action="<?php echo e(route('clientes.destroy', $cliente->id)); ?>" method="POST" style="display:inline-block;" onsubmit="return confirm('¿Deseas eliminar este cliente?')">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button class="btn btn-danger btn-sm">Eliminar</button>
                                                    </form>
                                                     <?php endif; ?>
                                                </td>
                                           
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\crud\resources\views\clientes\index.blade.php ENDPATH**/ ?>