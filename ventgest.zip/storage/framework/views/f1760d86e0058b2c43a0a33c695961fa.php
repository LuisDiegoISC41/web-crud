

<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="card shadow-sm border-0 rounded">
        <div class="card-header bg-primary text-white">
            <h4 class="mb-0">Detalle de Categoría</h4>
        </div>
        <div class="card-body">
            <p class="mb-2"><strong>Nombre:</strong> <span class="text-secondary"><?php echo e($categoria->Nombre); ?></span></p>
            <p class="mb-4"><strong>Descripción:</strong> <span class="text-secondary"><?php echo e($categoria->Descripcion); ?></span></p>

            <a href="<?php echo e(route('categorias.index')); ?>" class="btn btn-outline-secondary">Volver</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\crud\resources\views\categorias\show.blade.php ENDPATH**/ ?>